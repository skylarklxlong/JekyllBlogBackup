---
layout: page
title: 关于我
header: 关于我
group: navigation
---

一个 Android 小白，喜欢研究一些新技术。
<p>
平时喜欢整理个人笔记，逛逛技术论坛。
<p>
爱学习、爱读书、爱运动、爱生活、爱美食。
<p>

<h3> 我的博客 </h3>  

<p>
这个博客是使用 
<a href="https://onevcat.com/"> Vno - Jekyll </a>
博客的模版所搭建的。在此非常感谢！<a href="https://github.com/skylarklxlong/skylarklxlong.github.io"> Vno - Jekyll </a>是一个简洁的博客模板，如果你也喜欢请 Star ，你的 Star 是开发者持续更新的动力, 谢谢 😄.

<p>

如果你想搭建一个跟我一样的博客，可以看我的 
<a href="/2017/08/jekyll-blog-build/"> 使用Jekyll + GitHub Pages搭建个人博客 </a>
教程

<p>

有关于博客主题的建议和意见都可以提给我，让我们一起来打造一个精美的主题吧~  <a href="/liuyan/"> 留言版 </a>

<p> 

博客源码在 <a target="_blank" href='https://github.com/skylarklxlong/skylarklxlong.github.io/'> Github </a> 上，你的 Star 是我更新的动力，谢谢~

{% include comments.html %}
